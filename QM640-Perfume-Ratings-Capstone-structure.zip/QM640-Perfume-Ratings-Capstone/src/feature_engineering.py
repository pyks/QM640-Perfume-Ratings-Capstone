"""Feature engineering helpers for the QM640 perfume ratings capstone."""

import numpy as np
import pandas as pd


def add_log_votes(df: pd.DataFrame) -> pd.DataFrame:
    """Add log-transformed vote count to reduce right skew."""
    df = df.copy()
    df["log_num_votes"] = np.log1p(df["num_votes"])
    return df


def add_release_cohort(df: pd.DataFrame) -> pd.DataFrame:
    """Create release cohort groups from release_year."""
    df = df.copy()
    bins = [1989, 1999, 2009, 2019, 2024]
    labels = ["pre-2000", "2000-2009", "2010-2019", "2020-2024"]
    df["release_cohort"] = pd.cut(df["release_year"], bins=bins, labels=labels)
    return df
