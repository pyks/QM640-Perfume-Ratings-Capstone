"""Data cleaning helpers for the QM640 perfume ratings capstone."""

import pandas as pd


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Remove duplicate fragrance records using perfume_name and brand as composite keys."""
    return df.drop_duplicates(subset=["perfume_name", "brand"], keep="first")


def filter_valid_votes(df: pd.DataFrame) -> pd.DataFrame:
    """Keep records with at least one consumer vote."""
    return df[df["num_votes"].fillna(0) > 0].copy()


def filter_release_year(df: pd.DataFrame, start: int = 1990, end: int = 2024) -> pd.DataFrame:
    """Keep records within the study time scope."""
    return df[df["release_year"].between(start, end, inclusive="both")].copy()
