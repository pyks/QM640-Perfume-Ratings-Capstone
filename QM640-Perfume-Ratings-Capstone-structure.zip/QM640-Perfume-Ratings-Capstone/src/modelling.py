"""Model utilities for the QM640 perfume ratings capstone."""

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score


def build_random_forest(random_state: int = 42) -> RandomForestRegressor:
    """Create a baseline Random Forest Regressor."""
    return RandomForestRegressor(
        n_estimators=300,
        random_state=random_state,
        n_jobs=-1,
        max_features="sqrt"
    )


def cross_validate_rmse(model, X, y, cv: int = 5):
    """Return cross-validated RMSE scores."""
    scores = cross_val_score(model, X, y, scoring="neg_root_mean_squared_error", cv=cv)
    return -scores
