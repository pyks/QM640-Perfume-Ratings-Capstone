"""Visualization helpers for the QM640 perfume ratings capstone."""

import matplotlib.pyplot as plt


def save_rating_distribution(df, output_path: str):
    """Save histogram of rating_score."""
    fig, ax = plt.subplots()
    ax.hist(df["rating_score"].dropna(), bins=30)
    ax.set_title("Distribution of Consumer Rating Scores")
    ax.set_xlabel("Rating Score")
    ax.set_ylabel("Frequency")
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)
