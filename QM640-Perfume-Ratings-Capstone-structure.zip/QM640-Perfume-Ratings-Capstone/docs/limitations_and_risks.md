# Limitations and Risks

1. Consumer ratings reflect self-selected platform users and may not represent the general consumer population.
2. Fragrantica and Parfumo may use different rating scales and community norms.
3. Missing note documentation may be higher for older fragrances.
4. Brand tier classification may require subjective judgment.
5. Web scraping completeness depends on page structure and field availability.
6. High-dimensional note encoding may introduce sparse feature challenges.
