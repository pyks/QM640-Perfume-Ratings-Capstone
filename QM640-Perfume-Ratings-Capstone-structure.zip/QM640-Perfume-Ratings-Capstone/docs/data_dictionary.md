# Data Dictionary

| Variable Name | Definition | Data Type | Source | Notes |
|---|---|---|---|---|
| perfume_name | Commercial name of the fragrance product | String | Fragrantica | Composite key with brand |
| brand | Manufacturer or fragrance house | String | Fragrantica | Composite key with perfume_name |
| brand_tier | Brand positioning classification | Categorical | Derived | Luxury / Niche / Mass-market |
| rating_score | Mean consumer rating | Numeric | Fragrantica | Primary dependent variable |
| num_votes | Number of consumer votes | Integer | Fragrantica | Proxy for popularity |
| gender_label | Marketed gender | Categorical | Fragrantica | Masculine / Feminine / Unisex |
| concentration | Fragrance concentration format | Categorical | Fragrantica | EDP / EDT / EDC / Parfum / Other |
| release_year | Official launch year | Integer | Fragrantica | Used to derive release_cohort |
| top_notes | Top note ingredients | List/String | Fragrantica | One-hot encoded |
| heart_notes | Heart or middle note ingredients | List/String | Fragrantica | One-hot encoded |
| base_notes | Base note ingredients | List/String | Fragrantica | One-hot encoded |
| main_accords | Dominant olfactory accords | List/String | Fragrantica | One-hot encoded |
| longevity_votes | Consumer longevity perception | Ordinal categorical | Fragrantica | Optional control/exploratory variable |
| sillage_votes | Consumer sillage/projection perception | Ordinal categorical | Fragrantica | Optional control/exploratory variable |
| perfumer | Name of perfumer/nose | String | Parfumo | Secondary dataset |
| release_cohort | Time-period grouping | Categorical | Derived | pre-2000 / 2000-2009 / 2010-2019 / 2020-2024 |
