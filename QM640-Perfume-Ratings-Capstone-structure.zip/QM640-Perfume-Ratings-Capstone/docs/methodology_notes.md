# Methodology Notes

## RQ1: Olfactory Predictors of Rating
Planned methods:
- Multiple linear regression
- Random Forest Regressor
- SHAP values for feature interpretation

## RQ2: Concentration Effects
Planned methods:
- One-way ANOVA
- Tukey HSD post-hoc testing
- Regression with controls for note profile and brand tier

## RQ3: Gender Positioning and Release Cohort
Planned methods:
- Two-way ANOVA
- Gender × release cohort interaction analysis

## RQ4: Popularity Bias and Brand Moderation
Planned methods:
- Moderated multiple regression
- log(num_votes) × brand_tier interaction
