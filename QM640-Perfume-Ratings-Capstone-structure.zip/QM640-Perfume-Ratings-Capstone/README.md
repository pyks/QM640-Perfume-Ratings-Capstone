# QM640 Perfume Ratings Capstone

## Project Title
What Makes a Perfume Highly Rated? Predicting Consumer Ratings of Fragrances Using Olfactory, Product, and Market Characteristics

## Project Overview
This capstone project analyzes publicly available fragrance data to identify the olfactory, product, and market characteristics associated with higher consumer ratings.

The project uses data from:
- Fragrantica.com
- Parfumo dataset from the TidyTuesday open-data initiative

## Research Questions
1. Which olfactory characteristics are strongest predictors of consumer rating scores?
2. Does fragrance concentration format significantly affect consumer rating scores?
3. Does gender positioning influence ratings, and has this changed over release cohorts?
4. Does popularity, measured by number of votes, relate to ratings, and is this moderated by brand tier?

## Repository Structure
```text
data/
  raw/              Raw source datasets
  processed/        Cleaned analysis-ready datasets
  external/         Reference lists, brand tier mapping, lookup tables

notebooks/
  01_scraping.ipynb
  02_cleaning.ipynb
  03_eda.ipynb
  04_modelling_rq1.ipynb
  05_anova_rq2.ipynb
  06_gender_cohort_rq3.ipynb
  07_moderated_regression_rq4.ipynb
  08_model_evaluation.ipynb

src/
  data_cleaning.py
  feature_engineering.py
  modelling.py
  visualization.py

outputs/
  figures/          Charts and EDA visuals
  tables/           Exported result tables
  models/           Saved model objects

docs/
  data_dictionary.md
  methodology_notes.md
  limitations_and_risks.md

reports/
  interim/          Interim report PDF and source files
  final/            Final report PDF and source files

appendices/         Supporting material for reports
```

## Reproducibility
The notebooks are designed to be executed in numeric order from data collection through final modelling and evaluation.

## Author
Priyanka Sharma  
Walsh College  
QM640: Data Analytics Capstone
